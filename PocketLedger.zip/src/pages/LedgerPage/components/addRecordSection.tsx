import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { LedgerRecord } from "../types";
import { useState } from "react";

interface AddRecordSectionProps {
    onAddRecord: (record: LedgerRecord) => void;
}


export function AddRecordSection({onAddRecord}: AddRecordSectionProps){
    const [title, setTitle] = useState("");
    const [amount, setAmount] = useState("");
    const [type, setType] = useState("income");


    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if(!title.trim() || !amount.trim() || !type) {
            alert("请输入完整的记账信息！");
            return;
        }

        const newRecord:LedgerRecord = {
            id: crypto.randomUUID(),
            title,
            amount,
            type,
            date: new Date().toISOString(),
        };

        onAddRecord(newRecord);
        setTitle("");
        setAmount("");
        setType("income");
    }

    return(
        <section>
            <h2>新增记账</h2>
            <form onSubmit={handleSubmit}>
                <Input type="text" 
                    value={title} 
                    onChange={(e) => setTitle(e.target.value)} 
                    placeholder="请输入记账名称" 
                    className="w-1/4" />  
                <Input type="number" 
                    value={amount} 
                    onChange={(e) => setAmount(e.target.value)} 
                    placeholder="请输入记账金额" 
                    className="w-1/4" />
                <select name="type" id="type"
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                >
                    <option value="income">收入</option>
                    <option value="expense">支出</option>
                </select>
                <Button type="submit">添加记录</Button>
            </form>
        </section>
    )

}