import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, type FormEventHandler } from "react";
import type { GroupedRecords, LedgerRecord } from "../types";


interface LedgerListSectionProps {
    filteredRecords: LedgerRecord[];
    groupedRecords: GroupedRecords;

    onUpdateRecord: (id:string, 
        updates: Pick<LedgerRecord, "title" | "amount" | "type">
    ) => void;
    
    onDeleteRecord: (id: string) => void;
}

export function LedgerListSection(props: LedgerListSectionProps){
    const { filteredRecords, groupedRecords, onUpdateRecord, onDeleteRecord } = props;

    const [editingId, setEditingId] = useState<string | null>(null);
    const [editingTitle, setEditingTitle] = useState("");
    const [editingAmount, setEditingAmount] = useState("");
    const [editingType, setEditingType] = useState("income");

    const handleUpdateSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if(!editingId) {
            return;
        }
        const updateAmount = Number(editingAmount);
        const updateTitle = editingTitle.trim();
        if(!updateTitle || Number.isNaN(updateAmount) || updateAmount <= 0) {
            alert("请输入正确的记账信息！");
            return;
        }

        onUpdateRecord(editingId, {
            title: updateTitle,
            amount: editingAmount,
            type: editingType,
        });
        
        cancelEdit();
    }

    const cancelEdit = () => { 
        setEditingId(null);
        setEditingTitle("");
        setEditingAmount("");
        setEditingType("income");
    }

    const beginEdit = (record: LedgerRecord) => {
        setEditingId(record.id);
        setEditingTitle(record.title);
        setEditingAmount(record.amount);
        setEditingType(record.type);
    }
    

    return(
        <section>
            {/* <h2>记账列表</h2> */}
            {filteredRecords.length === 0 ? (
                <p>暂无记账记录</p>
            ) : (
                <div>
                    {[
                        {title: "今日", records: groupedRecords.today},
                        {title: "本月", records: groupedRecords.thisMonth},
                        {title: "更早", records: groupedRecords.earlier},
                    ].map((group) => (
                        group.records.length > 0 ? (
                            <div key={group.title}>
                                <h3>{group.title}</h3>
                                <ul>
                                    {group.records.map((record) => (
                                        <li key={record.id}>
                                            {editingId === record.id ? (
                                                <form onSubmit={handleUpdateSubmit}>
                                                    <Input value={editingTitle} 
                                                        onChange={(e) => setEditingTitle(e.target.value)} 
                                                    />
                                                    <Input value={editingAmount} 
                                                        onChange={(e) => setEditingAmount(e.target.value)} 
                                                    />
                                                    <select value={editingType} onChange={(e) => setEditingType(e.target.value)}>
                                                        <option value="income">收入</option>
                                                        <option value="expense">支出</option>
                                                    </select>
                                                    <div>
                                                        <Button type="submit">保存</Button>
                                                        <Button type="button" onClick={cancelEdit}>取消</Button>
                                                    </div>
                                                </form>
                                            ) : (
                                                <div>
                                                    <span>{record.title}</span>
                                                    <span>{record.amount}</span>
                                                    <span>{record.type}</span>
                                                    <Button type="button" onClick={() => beginEdit(record)}>编辑</Button>
                                                    <Button type="button" onClick={() => onDeleteRecord(record.id)}>删除</Button>
                                                </div>
                                            )
                                        }
                                    </li>
                                    ))}
                                </ul>
                            </div>
                        ) : null
                    ))}
                    </div>
                )}
        </section>
    )
}