import { useEffect, useMemo, useState } from "react";
import { AddRecordSection } from "./components/addRecordSection";
import { LedgerListSection } from "./components/ledgerListSection";
import type { LedgerRecord } from "./types";
import { groupRecordsByDate } from "./utils";
import { FilterSection } from "./components/filterSection";

export function LedgerPage(){
    const [filterType, setFilterType] = useState("all");
    const [records, setRecords] = useState<LedgerRecord[]>(
        localStorage.getItem("records") ? JSON.parse(localStorage.getItem("records")!) : []);

    useEffect(() => {
        localStorage.setItem("records", JSON.stringify(records));
    }, [records]);


    //添加记录
    const handleAddRecord = (newRecord: LedgerRecord) => {
        setRecords((current) => [...current, newRecord]);
    }
        
    const filteredRecords = useMemo(() => {
        if (filterType === "all") {
            return records;
        }
        return records.filter((record) => record.type === filterType);
    }, [filterType, records]);
    
    
    const groupedRecords = useMemo(() => 
        groupRecordsByDate(filteredRecords), [filteredRecords]);

    //更新记录
    const handleUpdateRecord = (id: string, updates: Pick<LedgerRecord, "title" | "amount" | "type">) => {
        setRecords((current) => 
            current.map((record) => 
                record.id === id ? {...record, ...updates} : record
            ),
        );
    }

    //删除记录
    const handleDeleteRecord = (id: string) => {
        setRecords((current) => current.filter((record) => record.id !== id));
    }

    return(
        <div>
            <h1>记账本</h1>
            <AddRecordSection 
                onAddRecord={handleAddRecord}
            />

            <FilterSection onFilterTypeChange={setFilterType} />

            <LedgerListSection 
                filteredRecords={filteredRecords}
                groupedRecords={groupedRecords}
                onUpdateRecord={handleUpdateRecord}
                onDeleteRecord={handleDeleteRecord}
                
            />
            
        </div>
    )
}