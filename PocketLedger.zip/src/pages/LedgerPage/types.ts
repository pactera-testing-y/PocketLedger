// 记账记录
export interface LedgerRecord {
    id: string;
    title: string;
    amount: string;
    type: string;
    date: string;
}

// 按日期分组的记账记录
export interface GroupedRecords {
    today: LedgerRecord[];
    thisMonth: LedgerRecord[];
    earlier: LedgerRecord[];
  }