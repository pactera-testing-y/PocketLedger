import type { GroupedRecords, LedgerRecord } from "./types";

// 按日期分组记账记录
export const groupRecordsByDate = (records: LedgerRecord[]) : GroupedRecords => {
    const now = new Date();
    const sorted = [...records].sort(
        (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    //遍历排序后的记录并累计到分组对象中
    return sorted.reduce(
        (group, record) => {
            const date = new Date(record.date);
            if (date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth() && date.getDate() === now.getDate()) {
                group.today.push(record);
            } else if (date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth()) {
                group.thisMonth.push(record);
            } else {
                group.earlier.push(record);
            }
            return group;
        },
        {
            today: [],
            thisMonth: [],
            earlier: [],
        } as GroupedRecords
    )
}