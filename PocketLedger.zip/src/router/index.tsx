import { LedgerPage } from "@/pages/LedgerPage";
import { createBrowserRouter } from "react-router";


const routers = [
    {
        path: "/",
        element: <LedgerPage />
    },
    {
        path: "/test",
        element: <div>TEST</div>
    }
];

export const router = createBrowserRouter(routers);